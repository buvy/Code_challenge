import React, {Component} from 'react';
import Item from './Item.js';
/**
 * Main Menu component
 * list down all the Menu
 * On click of each manu we can get the details of that particular menu
 * Responsible layout
 */

class Menu extends Component {
    componentDidMount(){
        this.props.actions.fetchData();
    }
    render(){
        return(
            <div className="maincontainer">
                {this.props.food.map((data, index)=> <Item {...data} id={index}/>)}
            </div>
        );
    }
}

export default Menu;