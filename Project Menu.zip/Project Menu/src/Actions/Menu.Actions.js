/**
 * Action file for fetching async data
 */

export function fetchData() {
    return dispatch => {
        fetch('/mock.json')
        .then(results => {
            console.log(results);
            return results.json();
        })
        .then(response => {
            dispatch({ type: "FETCH_SUCCESS", response})
            console.log(response, "response");
        });
    }
} 